package com.example.vlivattendance

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
