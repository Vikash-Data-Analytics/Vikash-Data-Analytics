import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'state/login_state.dart';
import 'client/home.dart';
import 'client/login.dart';
import 'client/signup.dart';
import 'client/attendance.dart';
import 'client/user.dart';
import 'client/my_logs.dart';
import 'client/admin_dashboard.dart';
import 'client/splash_screen.dart';
import 'client/leave.dart';
import 'client/leave_requests.dart';
import 'client/admin_user_management.dart';
import 'client/admin_attendance.dart';
import 'client/admin_logs.dart';
import 'client/forgot_password.dart';
import 'services/geofence_service.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => LoginState()),
        Provider(create: (context) => GeofenceService(radius: 100.0, latitude: 37.7749, longitude: -122.4194)),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<LoginState>(
      builder: (context, loginState, child) {
        return MaterialApp(
          title: 'Vliv Attendance',
          theme: ThemeData(
            primarySwatch: Colors.deepPurple,
            visualDensity: VisualDensity.adaptivePlatformDensity,
            textTheme: const TextTheme(
              headlineLarge: TextStyle(fontSize: 32.0, fontWeight: FontWeight.bold, color: Colors.deepPurple, fontFamily: 'Roboto'),
            ),
          ),
          initialRoute: loginState.isLoggedIn ? '/home' : '/login',
          routes: {
            '/': (context) => const SplashScreen(),
            '/login': (context) => const LoginPage(),
            '/signup': (context) => const SignupPage(),
            '/home': (context) => const HomePage(),
            '/attendance': (context) => const AttendancePage(),
            '/profile': (context) => const ProfilePage(),
            '/my_logs': (context) => const MyLogs(),
            '/admin_dashboard': (context) => const AdminDashboardPage(),
            '/leave': (context) => const LeavePage(),
            '/admin/leave_requests': (context) => const LeaveRequestsPage(),
            '/admin/user_management': (context) => const AdminUserManagementPage(),
            '/admin/attendance': (context) => const AttendancePage(),
            '/admin/logs': (context) => const MyLogs(),
            '/forgot-password': (context) => const ForgotPasswordPage(),
          },
        );
      },
    );
  }
}