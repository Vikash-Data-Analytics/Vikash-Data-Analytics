import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:charts_flutter/flutter.dart' as charts; // Changed chart library to charts_flutter
import '../state/login_state.dart';
import 'login.dart';
import 'user.dart'; 
import 'my_logs.dart';
import 'admin_dashboard.dart';
import 'leave.dart';
import 'attendance.dart'; 

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    final loginState = Provider.of<LoginState>(context);

    if (!loginState.isLoggedIn) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.pushReplacementNamed(
          context,
          '/login',
        );
      });
      return const SizedBox.shrink();
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
        backgroundColor: Colors.deepPurple,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            UserAccountsDrawerHeader(
              accountName: Text(loginState.username),
              accountEmail: Text(loginState.email),
              currentAccountPicture: CircleAvatar(
                backgroundColor: Colors.white,
                child: Text(
                  loginState.username.isNotEmpty ? loginState.username[0].toUpperCase() : '',
                  style: TextStyle(fontSize: 30.0, color: Colors.deepPurple), 
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text('Home'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushReplacementNamed(context, '/home');
              },
            ),
            if (loginState.isAdmin) ...[
              ListTile(
                leading: Icon(Icons.dashboard),
                title: Text('Admin Dashboard'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushReplacementNamed(context, '/admin_dashboard');
                },
              ),
              ListTile(
                leading: Icon(Icons.request_page),
                title: Text('Leave Requests'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushReplacementNamed(context, '/admin/leave_requests');
                },
              ),
              ListTile(
                leading: Icon(Icons.check_circle),
                title: Text('Admin Attendance'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushReplacementNamed(context, '/admin_attendance');
                },
              ),
              ListTile(
                leading: Icon(Icons.manage_accounts),
                title: Text('User Management'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushReplacementNamed(context, '/admin/user_management');
                },
              ),
              ListTile(
                leading: Icon(Icons.list),
                title: Text('Admin Logs'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushReplacementNamed(context, '/admin/logs');
                },
              ),
            ] else ...[
              ListTile(
                leading: Icon(Icons.person),
                title: Text('Profile'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushReplacementNamed(context, '/profile');
                },
              ),
              ListTile(
                leading: Icon(Icons.list),
                title: Text('Logs'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/my_logs');
                },
              ),
              ListTile(
                leading: Icon(Icons.beach_access),
                title: Text('Leave Management'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/leave');
                },
              ),
              ListTile(
                leading: Icon(Icons.check_circle),
                title: Text('Attendance'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/attendance');
                },
              ),
            ],
            ListTile(
              leading: Icon(Icons.logout),
              title: Text('Logout'),
              onTap: () async {
                bool confirm = await showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Text('Confirm Logout'),
                    content: Text('Are you sure you want to logout?'),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.of(context).pop(false),
                        child: Text('Cancel'),
                      ),
                      TextButton(
                        onPressed: () {
                          loginState.logout();
                          Navigator.of(context).pop(true);
                          Navigator.pushReplacementNamed(context, '/login');
                        },
                        child: Text('Logout'),
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          Center(
            child: Text(
              'Welcome to the Home Page!',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
          ),
          SizedBox(height: 16.0),
          Text(
            'Attendance Overview',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          SizedBox(
            height: 200,
            child: charts.BarChart(
              _createSampleData(),
              animate: true,
            ),
          ),
          SizedBox(height: 16.0),
          Text(
            'Leave Requests Overview',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          SizedBox(
            height: 200,
            child: charts.PieChart(
              _createSamplePieData(),
              animate: true,
            ),
          ),
        ],
      ),
    );
  }

  List<charts.Series<AttendanceData, String>> _createSampleData() {
    final data = [
      AttendanceData('Mon', 5),
      AttendanceData('Tue', 25),
      AttendanceData('Wed', 100),
      AttendanceData('Thu', 75),
      AttendanceData('Fri', 55),
    ];

    return [
      charts.Series<AttendanceData, String>(
        id: 'Attendance',
        colorFn: (_, __) => charts.MaterialPalette.blue.shadeDefault,
        domainFn: (AttendanceData attendance, _) => attendance.day,
        measureFn: (AttendanceData attendance, _) => attendance.count,
        data: data,
      )
    ];
  }

  List<charts.Series<LeaveData, String>> _createSamplePieData() {
    final data = [
      LeaveData('Approved', 40),
      LeaveData('Pending', 30),
      LeaveData('Rejected', 30),
    ];

    return [
      charts.Series<LeaveData, String>(
        id: 'Leave',
        colorFn: (LeaveData leave, _) {
          switch (leave.status) {
            case 'Approved':
              return charts.MaterialPalette.green.shadeDefault;
            case 'Pending':
              return charts.MaterialPalette.yellow.shadeDefault;
            case 'Rejected':
              return charts.MaterialPalette.red.shadeDefault;
            default:
              return charts.MaterialPalette.blue.shadeDefault;
          }
        },
        domainFn: (LeaveData leave, _) => leave.status,
        measureFn: (LeaveData leave, _) => leave.count,
        data: data,
      )
    ];
  }
}

class AttendanceData {
  final String day;
  final int count;

  AttendanceData(this.day, this.count);
}

class LeaveData {
  final String status;
  final int count;

  LeaveData(this.status, this.count);
}