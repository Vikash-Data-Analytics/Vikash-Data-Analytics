import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../state/login_state.dart';
import 'leave_request_model.dart';

class LeaveRequestsPage extends StatefulWidget {
  const LeaveRequestsPage({super.key});

  @override
  _LeaveRequestsPageState createState() => _LeaveRequestsPageState();
}

class _LeaveRequestsPageState extends State<LeaveRequestsPage> {
  @override
  Widget build(BuildContext context) {
    final loginState = Provider.of<LoginState>(context);

    if (!loginState.isLoggedIn || !loginState.isAdmin) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.pushReplacementNamed(context, '/login');
      });
      return const SizedBox.shrink();
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Leave Requests'),
        backgroundColor: Colors.deepPurple,
      ),
      body: FutureBuilder<List<LeaveRequest>>(
        future: fetchLeaveRequestsFromApi(loginState.token),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No leave requests found'));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                final leaveRequest = snapshot.data![index];
                return ListTile(
                  title: Text('Leave Request ${leaveRequest.id}'),
                  subtitle: Text('Status: ${leaveRequest.status}'),
                  onTap: () {
                    // Handle leave request tap
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => LeaveRequestDetailPage(leaveRequest: leaveRequest),
                      ),
                    );
                  },
                );
              },
            );
          }
        },
      ),
    );
  }

  Future<List<LeaveRequest>> fetchLeaveRequestsFromApi(String token) async {
    final response = await http.get(
      Uri.parse('http://127.0.0.1:5000/api/admin/leaves'),
      headers: {
        'Authorization': 'Bearer $token',
      },
    );

    if (response.statusCode == 200) {
      List<dynamic> body = jsonDecode(response.body);
      return body.map((dynamic item) => LeaveRequest.fromJson(item)).toList();
    } else {
      throw Exception('Failed to load leave requests');
    }
  }
}

class LeaveRequestDetailPage extends StatelessWidget {
  final LeaveRequest leaveRequest;

  const LeaveRequestDetailPage({required this.leaveRequest, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Leave Request ${leaveRequest.id}'),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('ID: ${leaveRequest.id}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 8),
            Text('Status: ${leaveRequest.status}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 8),
            Text('Reason: ${leaveRequest.reason}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 8),
            Text('Start Date: ${leaveRequest.startDate}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 8),
            Text('End Date: ${leaveRequest.endDate}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 8),
            Text('Leave Type: ${leaveRequest.leaveType}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                // Handle approve leave request
                _updateLeaveRequestStatus(context, leaveRequest.id, 'approved');
              },
              child: Text('Approve'),
            ),
            SizedBox(height: 8),
            ElevatedButton(
              onPressed: () {
                // Handle reject leave request
                _updateLeaveRequestStatus(context, leaveRequest.id, 'rejected');
              },
              child: Text('Reject'),
            ),
          ],
        ),
      ),
    );
  }

  void _updateLeaveRequestStatus(BuildContext context, int id, String status) async {
    final loginState = Provider.of<LoginState>(context, listen: false);
    final response = await http.put(
      Uri.parse('http://127.0.0.1:5000/api/admin/leaves/$id'),
      headers: {
        'Authorization': 'Bearer ${loginState.token}',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({'status': status}),
    );

    if (response.statusCode == 200) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Leave request $status successfully')));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to update leave request')));
    }
  }
}