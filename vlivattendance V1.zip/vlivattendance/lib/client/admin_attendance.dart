import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';
import '../state/login_state.dart';
import 'login.dart';

class AdminAttendancePage extends StatefulWidget {
  const AdminAttendancePage({super.key});

  @override
  _AdminAttendancePageState createState() => _AdminAttendancePageState();
}

class _AdminAttendancePageState extends State<AdminAttendancePage> {
  final TextEditingController _employeeIdController = TextEditingController();
  final TextEditingController _dateController = TextEditingController();
  final TextEditingController _timeController = TextEditingController();
  bool _isLoading = false;
  String _statusMessage = '';

  @override
  void initState() {
    super.initState();
    final loginState = Provider.of<LoginState>(context, listen: false);
    _employeeIdController.text = loginState.userId?.toString() ?? '';
    _dateController.text = DateFormat('yyyy-MM-dd').format(DateTime.now());
    _timeController.text = DateFormat('HH:mm:ss').format(DateTime.now());
  }

  Future<void> _submitAttendance(String token) async {
    setState(() {
      _isLoading = true;
      _statusMessage = '';
    });

    try {
      final response = await http.post(
        Uri.parse('http://127.0.0.1:5000/attendance'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode(<String, dynamic>{
          'employee_id': _employeeIdController.text,
          'date': _dateController.text,
          'time': _timeController.text,
          'type': _employeeIdController.text.isEmpty ? 'check_in' : 'check_out',
        }),
      );

      if (response.statusCode == 201) {
        setState(() {
          _statusMessage = 'Attendance marked successfully!';
        });
      } else {
        setState(() {
          _statusMessage = 'Failed to mark attendance: ${response.reasonPhrase}';
        });
      }
    } catch (e) {
      setState(() {
        _statusMessage = 'Error marking attendance: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final loginState = Provider.of<LoginState>(context);

    if (!loginState.isLoggedIn || loginState.role != 'admin') {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const LoginPage()),
        );
      });
      return const SizedBox.shrink();
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Attendance Management'),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextFormField(
              controller: _employeeIdController,
              decoration: InputDecoration(
                labelText: 'Employee ID',
                hintText: 'Enter employee ID',
                prefixIcon: Icon(Icons.badge),
              ),
            ),
            const SizedBox(height: 16.0),
            TextFormField(
              controller: _dateController,
              decoration: InputDecoration(
                labelText: 'Date',
                hintText: 'Enter date',
                prefixIcon: Icon(Icons.calendar_today),
              ),
            ),
            const SizedBox(height: 16.0),
            TextFormField(
              controller: _timeController,
              decoration: InputDecoration(
                labelText: 'Time',
                hintText: 'Enter time',
                prefixIcon: Icon(Icons.access_time),
              ),
            ),
            const SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: _isLoading ? null : () async {
                await _submitAttendance(loginState.token);
              },
              child: _isLoading
                  ? CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    )
                  : Text(_employeeIdController.text.isEmpty ? 'Check In' : 'Check Out'),
            ),
            const SizedBox(height: 16.0),
            Text(
              _statusMessage,
              style: TextStyle(color: Colors.red),
            ),
          ],
        ),
      ),
    );
  }
}