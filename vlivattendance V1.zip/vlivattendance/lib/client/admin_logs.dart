import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/login_state.dart';
import 'login.dart';

class AdminLogsPage extends StatelessWidget {
  const AdminLogsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<LoginState>(
      builder: (context, loginState, child) {
        if (loginState.role != 'admin') {
          return Scaffold(
            appBar: AppBar(
              title: const Text('Access Denied'),
              backgroundColor: Colors.deepPurple,
            ),
            body: Center(child: Text('You do not have permission to access this page.')),
          );
        }

        return FutureBuilder(
          future: loginState.fetchLogs(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Scaffold(
                appBar: AppBar(
                  title: const Text('Logs Management'),
                  backgroundColor: Colors.deepPurple,
                ),
                body: Center(child: CircularProgressIndicator()),
              );
            } else if (snapshot.hasError) {
              return Scaffold(
                appBar: AppBar(
                  title: const Text('Logs Management'),
                  backgroundColor: Colors.deepPurple,
                ),
                body: Center(child: Text('Error: ${snapshot.error}')),
              );
            } else {
              final logs = snapshot.data as List<dynamic>;
              return Scaffold(
                appBar: AppBar(
                  title: const Text('Logs Management'),
                  backgroundColor: Colors.deepPurple,
                ),
                body: ListView.builder(
                  itemCount: logs.length,
                  itemBuilder: (context, index) {
                    final log = logs[index];
                    return ListTile(
                      title: Text('Log ID: ${log['log_id']}'),
                      subtitle: Text('Message: ${log['log_message']}'),
                    );
                  },
                ),
              );
            }
          },
        );
      },
    );
  }
}