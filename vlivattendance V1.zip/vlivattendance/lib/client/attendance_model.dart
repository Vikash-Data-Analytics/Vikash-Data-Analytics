import 'package:flutter/material.dart';

class Attendance {
  final String employeeId;
  final DateTime date;
  final String type;
  final String status; // Added new field
  final String remarks; // Added new field

  Attendance({
    required this.employeeId,
    required this.date,
    required this.type,
    required this.status, // Added new field
    required this.remarks, // Added new field
  });

  factory Attendance.fromJson(Map<String, dynamic> json) {
    return Attendance(
      employeeId: json['employee_id'],
      date: DateTime.parse(json['date']),
      type: json['type'],
      status: json['status'], // Added new field
      remarks: json['remarks'], // Added new field
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'employee_id': employeeId,
      'date': date.toIso8601String(),
      'type': type,
      'status': status, // Added new field
      'remarks': remarks, // Added new field
    };
  }
}