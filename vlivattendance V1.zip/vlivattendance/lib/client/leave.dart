import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/login_state.dart';
import 'login.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class LeavePage extends StatefulWidget {
  const LeavePage({super.key});

  @override
  _LeavePageState createState() => _LeavePageState();
}

class _LeavePageState extends State<LeavePage> {
  bool _isLoading = false;
  String _statusMessage = '';
  final TextEditingController _startDateController = TextEditingController();
  final TextEditingController _endDateController = TextEditingController();
  final TextEditingController _reasonController = TextEditingController();
  final TextEditingController _leaveTypeController = TextEditingController(); // Added new field

  @override
  void initState() {
    super.initState();
    _startDateController.text = DateFormat('yyyy-MM-dd').format(DateTime.now());
    _endDateController.text = DateFormat('yyyy-MM-dd').format(DateTime.now());
  }

  Future<void> _selectDate(BuildContext context, TextEditingController controller) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null) {
      setState(() {
        controller.text = DateFormat('yyyy-MM-dd').format(picked);
      });
    }
  }

  Future<void> submitLeaveRequest() async {
    setState(() {
      _isLoading = true;
      _statusMessage = '';
    });

    final loginState = Provider.of<LoginState>(context, listen: false);
    final userId = loginState.userId;

    if (userId == null) {
      setState(() {
        _isLoading = false;
        _statusMessage = 'User not logged in. Redirecting to login page...';
      });
      await Future.delayed(const Duration(seconds: 2));
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const LoginPage()),
      );
      return;
    }

    try {
      final response = await http.post(
        Uri.parse('http://127.0.0.1:5000/leave'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
          'Authorization': 'Bearer ${loginState.token}',
        },
        body: jsonEncode(<String, dynamic>{
          'start_date': _startDateController.text,
          'end_date': _endDateController.text,
          'reason': _reasonController.text,
          'leave_type': _leaveTypeController.text, // Added new field
          'user_id': userId,
        }),
      );

      if (response.statusCode == 201) {
        setState(() {
          _statusMessage = 'Leave request submitted successfully!';
          _startDateController.clear();
          _endDateController.clear();
          _reasonController.clear();
          _leaveTypeController.clear(); // Added new field
        });
      } else {
        setState(() {
          _statusMessage = 'Failed to submit leave request: ${response.reasonPhrase}';
        });
      }
    } catch (e) {
      setState(() {
        _statusMessage = 'Error submitting leave request: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Leave Management'),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: <Widget>[
            TextFormField(
              controller: _startDateController,
              decoration: InputDecoration(
                labelText: 'Start Date',
                hintText: 'Enter start date',
                prefixIcon: Icon(Icons.calendar_today),
                border: OutlineInputBorder(),
              ),
              readOnly: true,
              onTap: () => _selectDate(context, _startDateController),
            ),
            const SizedBox(height: 16.0),
            TextFormField(
              controller: _endDateController,
              decoration: InputDecoration(
                labelText: 'End Date',
                hintText: 'Enter end date',
                prefixIcon: Icon(Icons.calendar_today),
                border: OutlineInputBorder(),
              ),
              readOnly: true,
              onTap: () => _selectDate(context, _endDateController),
            ),
            const SizedBox(height: 16.0),
            TextFormField(
              controller: _reasonController,
              decoration: InputDecoration(
                labelText: 'Reason',
                hintText: 'Enter reason for leave',
                prefixIcon: Icon(Icons.note),
                border: OutlineInputBorder(),
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 16.0),
            TextFormField(
              controller: _leaveTypeController, // Added new field
              decoration: InputDecoration(
                labelText: 'Leave Type', // Added new field
                hintText: 'Enter leave type', // Added new field
                prefixIcon: Icon(Icons.category), // Added new field
                border: OutlineInputBorder(), // Added new field
              ),
            ),
            const SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: _isLoading ? null : submitLeaveRequest,
              child: _isLoading
                  ? CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    )
                  : const Text('Submit Leave Request'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple,
                padding: EdgeInsets.symmetric(vertical: 15),
                textStyle: TextStyle(fontSize: 18),
              ),
            ),
            const SizedBox(height: 16.0),
            Text(
              _statusMessage,
              style: const TextStyle(color: Colors.red, fontSize: 16.0),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}