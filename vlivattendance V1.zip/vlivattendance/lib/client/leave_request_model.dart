class LeaveRequest {
  final int id;
  final String employeeId;
  final String reason;
  final String status;
  final DateTime startDate;
  final DateTime endDate;
  final String leaveType; // Added new field

  LeaveRequest({
    required this.id,
    required this.employeeId,
    required this.reason,
    required this.status,
    required this.startDate,
    required this.endDate,
    required this.leaveType, // Added new field
  });

  factory LeaveRequest.fromJson(Map<String, dynamic> json) {
    return LeaveRequest(
      id: json['id'],
      employeeId: json['employee_id'],
      reason: json['reason'],
      status: json['status'],
      startDate: DateTime.parse(json['start_date']),
      endDate: DateTime.parse(json['end_date']),
      leaveType: json['leave_type'], // Added new field
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'employee_id': employeeId,
      'reason': reason,
      'status': status,
      'start_date': startDate.toIso8601String(),
      'end_date': endDate.toIso8601String(),
      'leave_type': leaveType, // Added new field
    };
  }
}
