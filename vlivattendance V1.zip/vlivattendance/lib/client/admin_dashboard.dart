import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:charts_flutter/flutter.dart' as charts; // Changed chart library to charts_flutter
import '../state/login_state.dart';
import 'home.dart';
import 'login.dart';
import 'user.dart';
import 'attendance.dart';
import 'my_logs.dart';
import 'leave.dart';
import 'leave_requests.dart';
import 'admin_attendance.dart';
import 'admin_logs.dart';

class AdminDashboardPage extends StatefulWidget {
  const AdminDashboardPage({super.key});

  @override
  _AdminDashboardPageState createState() => _AdminDashboardPageState();
}

class _AdminDashboardPageState extends State<AdminDashboardPage> {
  @override
  Widget build(BuildContext context) {
    return Consumer<LoginState>(
      builder: (context, loginState, child) {
        if (loginState.role != 'admin') {
          return Scaffold(
            appBar: AppBar(
              title: const Text('Access Denied'),
              backgroundColor: Colors.deepPurple,
            ),
            body: Center(child: Text('You do not have permission to access this page.')),
          );
        }
        return Scaffold(
          appBar: AppBar(
            title: const Text('Admin Dashboard'),
            backgroundColor: Colors.deepPurple,
          ),
          body: ListView(
            children: [
              ListTile(
                leading: Icon(Icons.home),
                title: Text('Home'),
                onTap: () {
                  Navigator.pushReplacementNamed(context, '/home');
                },
              ),
              ListTile(
                leading: Icon(Icons.dashboard),
                title: Text('Admin Dashboard'),
                onTap: () {
                  Navigator.pushReplacementNamed(context, '/admin_dashboard');
                },
              ),
              ListTile(
                leading: Icon(Icons.request_page),
                title: Text('Leave Requests'),
                onTap: () {
                  Navigator.pushReplacementNamed(context, '/admin/leave_requests');
                },
              ),
              ListTile(
                leading: Icon(Icons.person),
                title: Text('User Management'),
                onTap: () {
                  Navigator.pushReplacementNamed(context, '/admin/user_management');
                },
              ),
              ListTile(
                leading: Icon(Icons.access_time),
                title: Text('Attendance Management'),
                onTap: () {
                  Navigator.pushReplacementNamed(context, '/admin/attendance');
                },
              ),
              ListTile(
                leading: Icon(Icons.logout),
                title: Text('Logout'),
                onTap: () {
                  loginState.logout();
                  Navigator.pushReplacementNamed(context, '/login');
                },
              ),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Text(
                      'Attendance Overview',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(
                      height: 200,
                      child: charts.BarChart(
                        _createSampleData(),
                        animate: true,
                      ),
                    ),
                    SizedBox(height: 16.0),
                    Text(
                      'Leave Requests Overview',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(
                      height: 200,
                      child: charts.PieChart(
                        _createSamplePieData(),
                        animate: true,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  List<charts.Series<AttendanceData, String>> _createSampleData() {
    final data = [
      AttendanceData('Mon', 5),
      AttendanceData('Tue', 25),
      AttendanceData('Wed', 100),
      AttendanceData('Thu', 75),
      AttendanceData('Fri', 55),
    ];

    return [
      charts.Series<AttendanceData, String>(
        id: 'Attendance',
        colorFn: (_, __) => charts.MaterialPalette.blue.shadeDefault,
        domainFn: (AttendanceData attendance, _) => attendance.day,
        measureFn: (AttendanceData attendance, _) => attendance.count,
        data: data,
      )
    ];
  }

  List<charts.Series<LeaveData, String>> _createSamplePieData() {
    final data = [
      LeaveData('Approved', 40),
      LeaveData('Pending', 30),
      LeaveData('Rejected', 30),
    ];

    return [
      charts.Series<LeaveData, String>(
        id: 'Leave',
        colorFn: (LeaveData leave, _) {
          switch (leave.status) {
            case 'Approved':
              return charts.MaterialPalette.green.shadeDefault;
            case 'Pending':
              return charts.MaterialPalette.yellow.shadeDefault;
            case 'Rejected':
              return charts.MaterialPalette.red.shadeDefault;
            default:
              return charts.MaterialPalette.blue.shadeDefault;
          }
        },
        domainFn: (LeaveData leave, _) => leave.status,
        measureFn: (LeaveData leave, _) => leave.count,
        data: data,
        labelAccessorFn: (LeaveData row, _) => '${row.status}: ${row.count}',
      )
    ];
  }
}

class AttendanceData {
  final String day;
  final int count;

  AttendanceData(this.day, this.count);
}

class LeaveData {
  final String status;
  final int count;

  LeaveData(this.status, this.count);
}