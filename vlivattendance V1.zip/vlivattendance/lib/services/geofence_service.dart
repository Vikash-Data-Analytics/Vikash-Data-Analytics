import 'package:geolocator/geolocator.dart';

class GeofenceService {
  final double radius;
  final double latitude;
  final double longitude;

  GeofenceService({
    required this.radius,
    required this.latitude,
    required this.longitude,
  });

  Future<Position?> _getCurrentPosition() async {
    try {
      return await Geolocator.getCurrentPosition();
    } catch (e) {
      print('Error getting current position: $e');
      return null;
    }
  }

  Future<bool> isWithinGeofence() async {
    Position? position = await _getCurrentPosition();
    if (position == null) {
      return false;
    }

    double distance = Geolocator.distanceBetween(
      latitude,
      longitude,
      position.latitude,
      position.longitude,
    );

    return distance <= radius;
  }

  Stream<bool> monitorGeofence() async* {
    await for (Position position in Geolocator.getPositionStream()) {
      double distance = Geolocator.distanceBetween(
        latitude,
        longitude,
        position.latitude,
        position.longitude,
      );

      yield distance <= radius;
    }
  }
}
