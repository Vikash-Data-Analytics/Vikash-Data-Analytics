import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class LoginState extends ChangeNotifier {
  bool _isLoggedIn = false;
  String _username = '';
  String _email = '';
  String _token = '';
  int? _userId;
  String _role = 'user';
  String _errorMessage = '';
  bool isLoading = false;

  bool get isLoggedIn => _isLoggedIn;
  bool get isAdmin => _role == 'admin';
  String get username => _username;
  String get email => _email;
  String get token => _token;
  int? get userId => _userId;
  String get role => _role;
  String get errorMessage => _errorMessage;

  Future<bool> login(String username, String password) async {
    print('Attempting login with username: $username'); // Debug print
    isLoading = true;
    notifyListeners();
    try {
      final response = await http.post(
        Uri.parse('http://127.0.0.1:5000/login'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, String>{
          'username': username,
          'password': password,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _isLoggedIn = true;
        _username = data['username'] ?? '';
        _email = data['email'] ?? '';
        _token = data['token'] ?? '';
        _userId = data['user_id'];
        _role = data['is_admin'] == true ? 'admin' : 'user';
        _errorMessage = '';
        await fetchUserProfile(); // Fetch user profile after login
        notifyListeners();
        return true;
      } else {
        _errorMessage = 'Invalid credentials';
        _isLoggedIn = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      _errorMessage = 'Error: $e';
      _isLoggedIn = false;
      notifyListeners();
      return false;
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> signup(String username, String password, String name, String email) async {
    isLoading = true;
    notifyListeners();
    try {
      final response = await http.post(
        Uri.parse('http://127.0.0.1:5000/signup'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, String>{
          'username': username,
          'password': password,
          'name': name,
          'email': email,
        }),
      );

      if (response.statusCode == 201) {
        final data = jsonDecode(response.body);
        _isLoggedIn = true;
        _username = data['username'] ?? '';
        _email = data['email'] ?? '';
        _token = data['token'] ?? '';
        _userId = data['user_id'];
        _role = data['is_admin'] == true ? 'admin' : 'user';
        _errorMessage = '';
        await fetchUserProfile(); // Fetch user profile after signup
        notifyListeners();
        return true;
      } else {
        _errorMessage = 'Signup failed';
        _isLoggedIn = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      _errorMessage = 'Error: $e';
      _isLoggedIn = false;
      notifyListeners();
      return false;
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  void logout() {
    _isLoggedIn = false;
    _username = '';
    _email = '';
    _token = '';
    _userId = null;
    _role = 'user';
    notifyListeners();
  }

  void updateProfile(String username, String email) {
    _username = username;
    _email = email;
    notifyListeners();
  }

  Future<void> fetchUserProfile() async {
    if (_token.isEmpty) return;

    try {
      final response = await http.get(
        Uri.parse('http://127.0.0.1:5000/profile/$_userId'),
        headers: <String, String>{
          'Authorization': 'Bearer $_token',
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _username = data['username'] ?? '';
        _email = data['email'] ?? '';
        notifyListeners();
      } else {
        _errorMessage = 'Failed to fetch user profile';
        notifyListeners();
      }
    } catch (e) {
      _errorMessage = 'Error: $e';
      notifyListeners();
    }
  }

  Future<void> fetchLogs() async {
    if (_token.isEmpty) return;

    try {
      final response = await http.get(
        Uri.parse('http://127.0.0.1:5000/logs'),
        headers: <String, String>{
          'Authorization': 'Bearer $_token',
        },
      );

      if (response.statusCode == 200) {
        logs = jsonDecode(response.body);
        notifyListeners();
      } else {
        _errorMessage = 'Failed to fetch logs';
        notifyListeners();
      }
    } catch (e) {
      _errorMessage = 'Error: $e';
      notifyListeners();
    }
  }

  Future<bool> updateUserProfile(String username, String email) async {
    if (_token.isEmpty) return false;

    isLoading = true;
    notifyListeners();

    try {
      final response = await http.put(
        Uri.parse('http://127.0.0.1:5000/profile/$_userId'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
          'Authorization': 'Bearer $_token',
        },
        body: jsonEncode(<String, String>{
          'username': username,
          'email': email,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _username = data['username'] ?? '';
        _email = data['email'] ?? '';
        _errorMessage = '';
        notifyListeners();
        return true;
      } else {
        _errorMessage = 'Failed to update profile';
        notifyListeners();
        return false;
      }
    } catch (e) {
      _errorMessage = 'Error: $e';
      notifyListeners();
      return false;
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  final TextEditingController loginUsernameController = TextEditingController();
  final TextEditingController loginPasswordController = TextEditingController();
  final GlobalKey<FormState> loginFormKey = GlobalKey<FormState>();

  final TextEditingController signupUsernameController = TextEditingController();
  final TextEditingController signupPasswordController = TextEditingController();
  final TextEditingController signupNameController = TextEditingController();
  final TextEditingController signupEmailController = TextEditingController();
  final GlobalKey<FormState> signupFormKey = GlobalKey<FormState>();

  final TextEditingController attendanceEmployeeIdController = TextEditingController();
  final TextEditingController attendanceDateController = TextEditingController();
  final TextEditingController attendanceCheckInController = TextEditingController();
  final TextEditingController attendanceCheckOutController = TextEditingController();
  final TextEditingController attendanceStatusController = TextEditingController();
  bool attendanceIsLoading = false;
  String attendanceStatusMessage = '';

  Map<String, dynamic> userProfile = {};

  List<dynamic> logs = [];
}