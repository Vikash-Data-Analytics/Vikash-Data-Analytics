from flask import Flask, request, jsonify, session, g, current_app
from flask_bcrypt import Bcrypt
from flask_cors import CORS
import mysql.connector
import jwt
import datetime
from datetime import timedelta
import re

app = Flask(__name__)
app.secret_key = "supersecretkey"
bcrypt = Bcrypt(app)
CORS(app, resources={r"/*": {"origins": "*"}})

def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="vlivattendance"
    )

def generate_token(user_id):
    payload = {
        'exp': datetime.datetime.utcnow() + datetime.timedelta(days=1),
        'iat': datetime.datetime.utcnow(),
        'sub': user_id
    }
    return jwt.encode(payload, app.secret_key, algorithm='HS256')

def decode_token(token):
    try:
        payload = jwt.decode(token, app.secret_key, algorithms=['HS256'])
        return payload['sub']
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None

@app.before_request
def load_logged_in_user():
    token = request.headers.get('Authorization')
    if token:
        token = token.split(" ")[1]
        user_id = decode_token(token)
        if user_id:
            db = get_db_connection()
            cursor = db.cursor(dictionary=True)
            cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
            g.user = cursor.fetchone()
            cursor.close()
            db.close()
        else:
            g.user = None
    else:
        g.user = None

def is_valid_email(email):
    return re.match(r"[^@]+@[^@]+\.[^@]+", email)

@app.route('/signup', methods=['POST'])
def signup():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    name = data.get('name')
    email = data.get('email')

    if not all([username, password, name, email]):
        return jsonify({'error': 'Missing data'}), 400
    if not is_valid_email(email):
        return jsonify({'error': 'Invalid email format'}), 400

    hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')

    db = get_db_connection()
    cursor = db.cursor()
    try:
        cursor.execute("INSERT INTO users (username, password, name, email) VALUES (%s, %s, %s, %s)", (username, hashed_password, name, email))
        db.commit()
    except mysql.connector.Error as err:
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()
        db.close()

    return jsonify({"message": "User registered successfully"}), 201

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    if not all([username, password]):
        return jsonify({'error': 'Missing data'}), 400

    db = get_db_connection()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
    user = cursor.fetchone()
    cursor.close()
    db.close()

    if user and bcrypt.check_password_hash(user['password'], password):
        token = generate_token(user['id'])
        return jsonify({"token": token, "user_id": user['id'], "is_admin": bool(user['is_admin'])}), 200
    else:
        return jsonify({"message": "Invalid credentials"}), 401

@app.route('/attendance', methods=['POST'])
def attendance():
    if g.user is None:
        return jsonify({"message": "Unauthorized"}), 401

    data = request.get_json()
    employee_id = data.get('employee_id')
    date = data.get('date')
    check_in = data.get('check_in')
    check_out = data.get('check_out')
    status = data.get('status')

    if not all([employee_id, date, status]):
        return jsonify({'error': 'Missing data'}), 400

    db = get_db_connection()
    cursor = db.cursor()
    try:
        cursor.execute("INSERT INTO attendance (employee_id, date, check_in, check_out, status) VALUES (%s, %s, %s, %s, %s)", (employee_id, date, check_in, check_out, status))
        db.commit()
        return jsonify({'message': 'Attendance recorded successfully'}), 201
    except mysql.connector.Error as err:
        if err.errno == mysql.connector.errorcode.ER_DUP_ENTRY:
            return jsonify({"message": "Attendance for this date already recorded"}), 400
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()
        db.close()

@app.route('/profile/<int:user_id>', methods=['GET'])
def get_profile(user_id):
    if g.user is None:
        return jsonify({"message": "Unauthorized"}), 401

    db = get_db_connection()
    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("SELECT id, username, name, email FROM users WHERE id = %s", (user_id,))
        user = cursor.fetchone()
        if user:
            return jsonify(user), 200
        else:
            return jsonify({"message": "User not found"}), 404
    except mysql.connector.Error as err:
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()
        db.close()

@app.route('/profile', methods=['POST'])
def update_profile():
    if g.user is None:
        return jsonify({"message": "Unauthorized"}), 401

    data = request.get_json()
    user_id = g.user['id']
    name = data.get('name')
    email = data.get('email')

    db = get_db_connection()
    cursor = db.cursor()
    try:
        cursor.execute("UPDATE users SET name = %s, email = %s WHERE id = %s", (name, email, user_id))
        db.commit()
    except mysql.connector.Error as err:
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()
        db.close()

    return jsonify({"message": "Profile updated successfully"}), 200

@app.route('/logout', methods=['POST'])
def logout():
    session.pop('user_id', None)
    return jsonify({"message": "Logout successful"}), 200

@app.route('/my_logs', methods=['GET'])
def my_logs():
    if g.user is None:
        return jsonify({"message": "Unauthorized"}), 401

    user_id = g.user['id']
    db = get_db_connection()
    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("SELECT date, check_in, check_out, status FROM attendance WHERE employee_id = %s", (user_id,))
        logs = cursor.fetchall()
        for log in logs:
            if isinstance(log['check_in'], timedelta):
                log['check_in'] = str(log['check_in'])
            if isinstance(log['check_out'], timedelta):
                log['check_out'] = str(log['check_out'])
        return jsonify(logs), 200
    except mysql.connector.Error as err:
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()
        db.close()

@app.route('/leave', methods=['POST'])
def apply_leave():
    if g.user is None:
        return jsonify({"message": "Unauthorized"}), 401

    data = request.get_json()
    start_date = data.get('start_date')
    end_date = data.get('end_date')
    reason = data.get('reason')

    if not all([start_date, end_date, reason]):
        return jsonify({'error': 'Missing data'}), 400

    db = get_db_connection()
    cursor = db.cursor()
    try:
        cursor.execute("INSERT INTO leave_requests (user_id, start_date, end_date, reason) VALUES (%s, %s, %s, %s)", (g.user['id'], start_date, end_date, reason))
        db.commit()
        return jsonify({'message': 'Leave request submitted successfully'}), 201
    except mysql.connector.Error as err:
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()
        db.close()

@app.route('/leave/<int:leave_id>', methods=['PUT'])
def update_leave_status(leave_id):
    if g.user is None or not g.user.get('is_admin'):
        return jsonify({"message": "Unauthorized"}), 401

    data = request.get_json()
    status = data.get('status')

    if status not in ['approved', 'rejected']:
        return jsonify({'error': 'Invalid status'}), 400

    db = get_db_connection()
    cursor = db.cursor()
    try:
        cursor.execute("UPDATE leave_requests SET status = %s WHERE id = %s", (status, leave_id))
        db.commit()
        return jsonify({'message': 'Leave status updated successfully'}), 200
    except mysql.connector.Error as err:
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()
        db.close()

@app.route('/leaves', methods=['GET'])
def get_leave_requests():
    if g.user is None:
        return jsonify({"message": "Unauthorized"}), 401

    db = get_db_connection()
    cursor = db.cursor(dictionary=True)
    try:
        if g.user.get('is_admin'):
            cursor.execute("SELECT * FROM leave_requests")
        else:
            cursor.execute("SELECT * FROM leave_requests WHERE user_id = %s", (g.user['id'],))
        leave_requests = cursor.fetchall()
        return jsonify(leave_requests), 200
    except mysql.connector.Error as err:
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()
        db.close()

@app.route('/admin/leave_requests', methods=['GET'])
def admin_leave_requests():
    if g.user is None or not g.user.get('is_admin'):
        return jsonify({"message": "Unauthorized"}), 401

    db = get_db_connection()
    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM leave_requests")
        leave_requests = cursor.fetchall()
        return jsonify(leave_requests), 200
    except mysql.connector.Error as err:
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()
        db.close()

@app.route('/admin/users', methods=['GET'])
def admin_get_users():
    if g.user is None or not g.user.get('is_admin'):
        return jsonify({"message": "Unauthorized"}), 401

    db = get_db_connection()
    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("SELECT id, username, name, email, is_admin FROM users")
        users = cursor.fetchall()
        return jsonify(users), 200
    except mysql.connector.Error as err:
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()
        db.close()

@app.route('/admin/users/<int:user_id>', methods=['PUT'])
def admin_update_user(user_id):
    if g.user is None or not g.user.get('is_admin'):
        return jsonify({"message": "Unauthorized"}), 401

    data = request.get_json()
    name = data.get('name')
    email = data.get('email')
    is_admin = data.get('is_admin')

    db = get_db_connection()
    cursor = db.cursor()
    try:
        cursor.execute("UPDATE users SET name = %s, email = %s, is_admin = %s WHERE id = %s", (name, email, is_admin, user_id))
        db.commit()
        return jsonify({'message': 'User updated successfully'}), 200
    except mysql.connector.Error as err:
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()
        db.close()

@app.route('/admin/users/<int:user_id>', methods=['DELETE'])
def admin_delete_user(user_id):
    if g.user is None or not g.user.get('is_admin'):
        return jsonify({"message": "Unauthorized"}), 401

    db = get_db_connection()
    cursor = db.cursor()
    try:
        cursor.execute("DELETE FROM users WHERE id = %s", (user_id,))
        db.commit()
        return jsonify({'message': 'User deleted successfully'}), 200
    except mysql.connector.Error as err:
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()
        db.close()

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')