from flask import Flask, request, jsonify, session, g, current_app
from flask_bcrypt import Bcrypt
from flask_cors import CORS
import psycopg2
import psycopg2.extras
import jwt
import datetime
from datetime import timedelta
import re  

app = Flask(__name__)
app.secret_key = "supersecretkey"
bcrypt = Bcrypt(app)
CORS(app, resources={r"/*": {"origins": "*"}})

db = psycopg2.connect("postgresql://vikash:SqmnKjbAmVkmVIp3SpmJqaRbiqEQIbGK@dpg-cq4ebe6ehbks73ba9utg-a.oregon-postgres.render.com/product_0lcy")

def create_tables():
    cursor = db.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        is_admin BOOLEAN DEFAULT FALSE
    );
    """)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS attendance (
        id SERIAL PRIMARY KEY,
        employee_id INTEGER NOT NULL,
        date DATE NOT NULL,
        check_in TIME,
        check_out TIME,
        status VARCHAR(50) NOT NULL,
        FOREIGN KEY (employee_id) REFERENCES users (id)
    );
    """)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS leave_requests (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL,
        start_date DATE NOT NULL,
        end_date DATE NOT NULL,
        reason TEXT NOT NULL,
        status VARCHAR(50) DEFAULT 'pending',
        FOREIGN KEY (user_id) REFERENCES users (id)
    );
    """)
    db.commit()
    cursor.close()

create_tables()

def generate_token(user_id):
    payload = {
        'exp': datetime.datetime.now() + datetime.timedelta(days=1),
        'iat': datetime.datetime.now(),
        'sub': user_id
    }
    return jwt.encode(payload, app.secret_key, algorithm='HS256')

def decode_token(token):
    try:
        payload = jwt.decode(token, app.secret_key, algorithms=['HS256'])
        return payload['sub']
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None

@app.before_request
def load_logged_in_user():
    token = request.headers.get('Authorization')
    if token:
        token = token.split(" ")[1] 
        user_id = decode_token(token)
        if user_id:
            cursor = db.cursor(cursor_factory=psycopg2.extras.DictCursor)
            cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
            g.user = cursor.fetchone()
            cursor.close()
        else:
            g.user = None
    else:
        g.user = None

def is_valid_email(email):
    return re.match(r"[^@]+@[^@]+\.[^@]+", email)

@app.route('/signup', methods=['POST'])
def signup():
    data = request.get_json()
    username = data['username']
    password = data['password']
    name = data['name']
    email = data['email']

    if not all([username, password, name, email]):
        return jsonify({'error': 'Missing data'}), 400
    if not is_valid_email(email):
        return jsonify({'error': 'Invalid email format'}), 400

    hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')

    cursor = db.cursor()
    try:
        cursor.execute("INSERT INTO users (username, password, name, email) VALUES (%s, %s, %s, %s)", (username, hashed_password, name, email))
        db.commit()
    except psycopg2.Error as err:
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()

    return jsonify({"message": "User registered successfully"}), 201

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    if not all([username, password]):
        return jsonify({'error': 'Missing data'}), 400

    cursor = db.cursor(cursor_factory=psycopg2.extras.DictCursor)
    cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
    user = cursor.fetchone()
    cursor.close()

    if user and bcrypt.check_password_hash(user['password'], password):
        token = generate_token(user['id'])
        return jsonify({"token": token, "user_id": user['id'], "is_admin": bool(user['is_admin'])}), 200
    else:
        return jsonify({"message": "Invalid credentials"}), 401

@app.route('/attendance', methods=['POST'])
def attendance():
    if g.user is None:
        return jsonify({"message": "Unauthorized"}), 401

    data = request.get_json()
    employee_id = data.get('employee_id')
    date = data.get('date')
    check_in = data.get(timedelta.now())
    check_out = data.get(timedelta.now())
    status = data.get('status')

    if not all([employee_id, date, status]):
        return jsonify({'error': 'Missing data'}), 400

    cursor = db.cursor()
    try:
        cursor.execute("INSERT INTO attendance (employee_id, date, check_in, check_out, status) VALUES (%s, %s, %s, %s, %s)", (employee_id, date, check_in, check_out, status))
        db.commit()
        return jsonify({'message': 'Attendance recorded successfully'}), 201
    except psycopg2.Error as err:
        if err.pgcode == '23505': 
            return jsonify({"message": "Attendance for this date already recorded"}), 400
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()

@app.route('/profile/<int:user_id>', methods=['GET'])
def get_profile(user_id):
    if g.user is None:
        return jsonify({"message": "Unauthorized"}), 401

    cursor = db.cursor(cursor_factory=psycopg2.extras.DictCursor)
    try:
        cursor.execute("SELECT id, username, name, email FROM users WHERE id = %s", (user_id,))
        user = cursor.fetchone()
        if user:
            return jsonify(user), 200
        else:
            return jsonify({"message": "User not found"}), 404
    except psycopg2.Error as err:
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()

@app.route('/profile', methods=['POST'])
def update_profile():
    if g.user is None:
        return jsonify({"message": "Unauthorized"}), 401

    data = request.get_json()
    user_id = g.user['id']
    name = data['name']
    email = data['email']

    cursor = db.cursor()
    try:
        cursor.execute("UPDATE users SET name = %s, email = %s WHERE id = %s", (name, email, user_id))
        db.commit()
    except psycopg2.Error as err:
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()

    return jsonify({"message": "Profile updated successfully"}), 200

@app.route('/logout', methods=['POST'])
def logout():
    session.pop('user_id', None)
    return jsonify({"message": "Logout successful"}), 200

@app.route('/my_logs', methods=['GET'])
def my_logs():
    if g.user is None:
        return jsonify({"message": "Unauthorized"}), 401

    user_id = g.user['id']
    cursor = db.cursor(cursor_factory=psycopg2.extras.DictCursor)
    try:
        cursor.execute("SELECT date, check_in, check_out, status FROM attendance WHERE employee_id = %s", (user_id,))
        logs = cursor.fetchall()
        for log in logs:
            if isinstance(log['check_in'], timedelta):
                log['check_in'] = str(log['check_in'])
            if isinstance(log['check_out'], timedelta):
                log['check_out'] = str(log['check_out'])
        return jsonify(logs), 200
    except psycopg2.Error as err:
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()

@app.route('/leave', methods=['POST'])
def apply_leave():
    if g.user is None:
        return jsonify({"message": "Unauthorized"}), 401

    data = request.get_json()
    start_date = data.get('start_date')
    end_date = data.get('end_date')
    reason = data.get('reason')

    if not all([start_date, end_date, reason]):
        return jsonify({'error': 'Missing data'}), 400

    cursor = db.cursor()
    try:
        cursor.execute("INSERT INTO leave_requests (user_id, start_date, end_date, reason) VALUES (%s, %s, %s, %s)", (g.user['id'], start_date, end_date, reason))
        db.commit()
        return jsonify({'message': 'Leave request submitted successfully'}), 201
    except psycopg2.Error as err:
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()

@app.route('/leave/<int:leave_id>', methods=['PUT'])
def update_leave_status(leave_id):
    if g.user is None or not g.user.get('is_admin'):
        return jsonify({"message": "Unauthorized"}), 401

    data = request.get_json()
    status = data.get('status')

    if status not in ['approved', 'rejected']:
        return jsonify({'error': 'Invalid status'}), 400

    cursor = db.cursor()
    try:
        cursor.execute("UPDATE leave_requests SET status = %s WHERE id = %s", (status, leave_id))
        db.commit()
        return jsonify({'message': 'Leave status updated successfully'}), 200
    except psycopg2.Error as err:
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()

@app.route('/leaves', methods=['GET'])
def get_leave_requests():
    if g.user is None:
        return jsonify({"message": "Unauthorized"}), 401

    cursor = db.cursor(cursor_factory=psycopg2.extras.DictCursor)
    try:
        if g.user.get('is_admin'):
            cursor.execute("SELECT * FROM leave_requests")
        else:
            cursor.execute("SELECT * FROM leave_requests WHERE user_id = %s", (g.user['id'],))
        leave_requests = cursor.fetchall()
        return jsonify(leave_requests), 200
    except psycopg2.Error as err:
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()

@app.route('/admin/leave_requests', methods=['GET'])
def admin_leave_requests():
    if g.user is None or not g.user.get('is_admin'):
        return jsonify({"message": "Unauthorized"}), 401

    cursor = db.cursor(cursor_factory=psycopg2.extras.DictCursor)
    try:
        cursor.execute("SELECT * FROM leave_requests")
        leave_requests = cursor.fetchall()
        return jsonify(leave_requests), 200
    except psycopg2.Error as err:
        return jsonify({"message": f"Error: {err}"}), 500
    finally:
        cursor.close()

if __name__ == '__main__':
    app.run(debug=True)
