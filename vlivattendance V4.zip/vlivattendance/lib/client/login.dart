import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:vlivattendance/state/login_state.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isLoading = false;
  bool _obscureText = true;

  Future<void> _login(LoginState loginState) async {
    setState(() {
      _isLoading = true;
    });

    final success = await loginState.login(
      _usernameController.text,
      _passwordController.text,
    );

    setState(() {
      _isLoading = false;
    });

    if (success) {
      Navigator.pushReplacementNamed(context, '/home');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(loginState.errorMessage)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final loginState = Provider.of<LoginState>(context);

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF1C4167), Color(0xFF37668F), Color(0xFFF4FAFF)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center, 
              children: [
                Image.asset(
                  'assets/logo.png',
                  width: 160,
                  height: 60,
                ),
                const SizedBox(height: 40.0),
                Text(
                  'Sign in',
                  style: TextStyle(
                    fontSize: 36.0,
                    color: Color(0xFFF4FAFF),
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 40.0),
                TextFormField(
                  controller: _usernameController,
                  decoration: InputDecoration(
                    labelText: 'User ID',
                    hintText: 'Enter your user ID',
                    prefixIcon: Icon(Icons.person, color: Color(0xFFF4FAFF)),
                    filled: true,
                    fillColor: Color(0xFFF4FAFF).withOpacity(0.1),
                    labelStyle: TextStyle(color: Color(0xFFF4FAFF)),
                    hintStyle: TextStyle(color: Color(0xFFF4FAFF).withOpacity(0.7)),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide.none,
                    ),
                  ),
                  style: TextStyle(color: Color(0xFFF4FAFF)),
                ),
                const SizedBox(height: 20.0),
                TextFormField(
                  controller: _passwordController,
                  decoration: InputDecoration(
                    labelText: 'Password',
                    hintText: 'Enter your password',
                    prefixIcon: Icon(Icons.lock, color: Color(0xFFF4FAFF)),
                    filled: true,
                    fillColor: Color(0xFFF4FAFF).withOpacity(0.1),
                    labelStyle: TextStyle(color: Color(0xFFF4FAFF)),
                    hintStyle: TextStyle(color: Color(0xFFF4FAFF).withOpacity(0.7)),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide.none,
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _obscureText ? Icons.visibility_off : Icons.visibility,
                        color: Color(0xFFF4FAFF),
                      ),
                      onPressed: () {
                        setState(() {
                          _obscureText = !_obscureText;
                        });
                      },
                    ),
                  ),
                  obscureText: _obscureText,
                  style: TextStyle(color: Color(0xFFF4FAFF)),
                ),
                const SizedBox(height: 40.0),
                ElevatedButton(
                  onPressed: _isLoading
                      ? null
                      : () async {
                          await _login(loginState);
                        },
                  child: _isLoading
                      ? CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF1C4167)),
                        )
                      : Text('Log In'),
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(horizontal: 60, vertical: 20),
                    textStyle: TextStyle(fontSize: 20),
                    backgroundColor: Color(0xFFF4FAFF),  
                    foregroundColor: Color(0xFF1C4167), 
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}