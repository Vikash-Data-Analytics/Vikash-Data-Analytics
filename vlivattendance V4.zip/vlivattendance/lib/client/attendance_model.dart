import 'package:flutter/material.dart';
class Attendance {
  final String employeeId;
  final DateTime date;
  final String type;
  final String status; 
  final String remarks; 

  Attendance({
    required this.employeeId,
    required this.date,
    required this.type,
    required this.status, 
    required this.remarks, 
  });

  factory Attendance.fromJson(Map<String, dynamic> json) {
    return Attendance(
      employeeId: json['employee_id'],
      date: DateTime.parse(json['date']),
      type: json['type'],
      status: json['status'], 
      remarks: json['remarks'], 
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'employee_id': employeeId,
      'date': date.toIso8601String(),
      'type': type,
      'status': status, 
      'remarks': remarks, 
    };
  }
}