import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';
import '../state/login_state.dart';
import 'dart:async';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:permission_handler/permission_handler.dart';

class AttendancePage extends StatefulWidget {
  const AttendancePage({super.key});

  @override
  _AttendancePageState createState() => _AttendancePageState();
}

class _AttendancePageState extends State<AttendancePage> {
  final TextEditingController _dateController = TextEditingController();
  final TextEditingController _timeController = TextEditingController();
  bool _isLoading = false;
  String _statusMessage = '';
  DateTime? _checkInTime;
  Timer? _timer;
  GoogleMapController? _mapController;
  Position? _currentPosition;
  final Set<Marker> _markers = {};
  bool _isMapReady = false;

  @override
  void initState() {
    super.initState();
    _dateController.text = DateFormat('dd/MM/yyyy').format(DateTime.now());
    _timeController.text = DateFormat('hh:mm a').format(DateTime.now());
    _startTimer();
    _getCurrentLocation();
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (Timer timer) {
      setState(() {
        _timeController.text = DateFormat('hh:mm:ss a').format(DateTime.now());
      });
    });
  }

  Future<void> _getCurrentLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      setState(() {
        _statusMessage = 'Location services are disabled. Please enable the services';
      });
      return;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        setState(() {
          _statusMessage = 'Location permissions are denied';
        });
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      setState(() {
        _statusMessage = 'Location permissions are permanently denied, we cannot request permissions.';
      });
      return;
    }

    try {
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      setState(() {
        _currentPosition = position;
        _markers.add(
          Marker(
            markerId: MarkerId('currentLocation'),
            position: LatLng(position.latitude, position.longitude),
            infoWindow: InfoWindow(title: 'Current Location'),
          ),
        );
        _isMapReady = true;
      });
    } catch (e) {
      setState(() {
        _statusMessage = 'Failed to get current location: $e';
      });
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _checkIn(String token, String employeeId, String companyId, String userName, String companyEmail, String reportingManager) async {
    setState(() {
      _isLoading = true;
      _statusMessage = '';
    });

    _checkInTime = DateTime.now();

    try {
      final response = await http.post(
        Uri.parse('https://hrms.vliv.app/atte/checkin'),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'employeeid': employeeId,
          'name': userName,
          'date': _dateController.text,
          'day': DateFormat('EEEE').format(DateTime.now()),
          'month': DateFormat('MMMM').format(DateTime.now()),
          'year': DateFormat('yyyy').format(DateTime.now()),
          'checkin': DateFormat('hh:mm:ss a').format(_checkInTime!),
          'checkout': '',
          'totalhours': '',
          'requeststatus': '',
          'approvestatus': '',
          'companyemail': companyEmail,
          'reason': '',
          'requesttype': '',
          'reportingto': reportingManager,
          'companyid': companyId,
          'latitude': _currentPosition?.latitude,
          'longitude': _currentPosition?.longitude,
        }),
      );

      if (response.statusCode == 200) {
        setState(() {
          _statusMessage = 'Check-in successful';
        });
      } else {
        setState(() {
          _statusMessage = 'Failed to check in: ${response.body}';
        });
      }
    } catch (e) {
      setState(() {
        _statusMessage = 'Failed to check in: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _checkOut(String token, String employeeId, String companyId, String companyEmail) async {
    setState(() {
      _isLoading = true;
      _statusMessage = '';
    });

    try {
      final response = await http.post(
        Uri.parse('https://hrms.vliv.app/atte/getbyemployee'),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'employeeid': employeeId,
          'companyid': companyId,
          'companyemail': companyEmail,
        }),
      );

      if (response.statusCode == 200) {
        final responseBody = jsonDecode(response.body);
        if (responseBody is Map && responseBody.containsKey('data')) {
          final logs = responseBody['data'];
          if (logs.isNotEmpty) {
            final lastLog = logs.last;
            _checkInTime = DateFormat('hh:mm:ss a').parse(lastLog['checkin']);
          } else {
            setState(() {
              _statusMessage = 'No check-in record found. Please check in first.';
              _isLoading = false;
            });
            return;
          }
        } else {
          setState(() {
            _statusMessage = 'Unexpected response format: $responseBody';
            _isLoading = false;
          });
          return;
        }
      } else {
        setState(() {
          _statusMessage = 'Failed to fetch logs: ${response.body}';
          _isLoading = false;
        });
        return;
      }
    } catch (e) {
      setState(() {
        _statusMessage = 'Failed to fetch logs: $e';
        _isLoading = false;
      });
      return;
    }

    final checkOutTime = DateTime.now();
    final totalDuration = checkOutTime.difference(_checkInTime!);

    final totalHours = totalDuration.inHours.toString().padLeft(2, '0') + ':' +
                       (totalDuration.inMinutes % 60).toString().padLeft(2, '0') + ':' +
                       (totalDuration.inSeconds % 60).toString().padLeft(2, '0');

    try {
      final response = await http.post(
        Uri.parse('https://hrms.vliv.app/atte/checkout'),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'date': _dateController.text,
          'employeeid': employeeId,
          'checkout': DateFormat('hh:mm:ss a').format(checkOutTime),
          'totalhours': totalHours,
          'companyid': companyId,
        }),
      );

      if (response.statusCode == 200) {
        setState(() {
          _statusMessage = 'Check-out successful';
        });
      } else {
        setState(() {
          _statusMessage = 'Failed to check out: ${response.body}';
        });
      }
    } catch (e) {
      setState(() {
        _statusMessage = 'Failed to check out: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final loginState = Provider.of<LoginState>(context);

    if (!loginState.isLoggedIn) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.pushReplacementNamed(context, '/login');
      });
      return const SizedBox.shrink();
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Attendance'),
        backgroundColor: Colors.deepPurple,
      ),
      body: Stack(
        children: [
          _isMapReady
              ? GoogleMap(
                  initialCameraPosition: CameraPosition(
                    target: LatLng(
                      _currentPosition!.latitude,
                      _currentPosition!.longitude,
                    ),
                    zoom: 15,
                  ),
                  markers: _markers,
                  onMapCreated: (GoogleMapController controller) {
                    _mapController = controller;
                  },
                )
              : Center(child: CircularProgressIndicator()),
          Positioned(
            left: 16,
            right: 16,
            bottom: 16,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  _dateController.text,
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                ),
                SizedBox(height: 8),
                Text(
                  _timeController.text,
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                ),
                SizedBox(height: 16),
                if (_isLoading)
                  CircularProgressIndicator()
                else
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton(
                        onPressed: () => _checkIn(
                          loginState.token,
                          loginState.employeeId,
                          loginState.companyId,
                          loginState.userName,
                          loginState.companyEmail,
                          loginState.reportingManager,
                        ),
                        child: const Text('Check In'),
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                          textStyle: const TextStyle(fontSize: 18),
                        ),
                      ),
                      ElevatedButton(
                        onPressed: () => _checkOut(
                          loginState.token,
                          loginState.employeeId,
                          loginState.companyId,
                          loginState.companyEmail,
                        ),
                        child: const Text('Check Out'),
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                          textStyle: const TextStyle(fontSize: 18),
                        ),
                      ),
                    ],
                  ),
                SizedBox(height: 8),
                Text(
                  _statusMessage,
                  style: const TextStyle(color: Colors.red, fontSize: 16),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
