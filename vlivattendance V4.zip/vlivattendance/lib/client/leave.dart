import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import '../state/login_state.dart';

class LeavePage extends StatefulWidget {
  const LeavePage({super.key});

  @override
  _LeavePageState createState() => _LeavePageState();
} 

class _LeavePageState extends State<LeavePage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _fromDateController = TextEditingController();
  final TextEditingController _toDateController = TextEditingController();
  final TextEditingController _reasonController = TextEditingController();
  final TextEditingController _leaveBalanceController = TextEditingController();
  final TextEditingController _noOfDaysController = TextEditingController();
  final TextEditingController _appliedToController = TextEditingController();
  String? _selectedLeaveType;
  String? _selectedCC;
  Map<String, int> _leaveTypes = {};
  List<String> _ccEmployees = [];
  List<String> _managers = [];
  bool _isLoading = false;
  String _statusMessage = '';
  bool _firstHalf = false;
  bool _secondHalf = false;
  String? _attachFile;
  String _date = '';

  @override
  void initState() {
    super.initState();
    _fetchInitialData();
  }

  Future<void> _fetchInitialData() async {
    await Future.wait([
      _fetchLeaveTypes(),
      _fetchEmployees(),
    ]);
  }

  Future<void> _fetchLeaveTypes() async {
    final loginState = Provider.of<LoginState>(context, listen: false);
    try {
      final response = await http.post(
        Uri.parse('https://hrms.vliv.app/attedance/leavetype/gettype'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'companyemail': loginState.companyEmail,
          'companyid': loginState.companyId,
        }),
      );

      if (response.statusCode == 200) {
        final responseBody = jsonDecode(response.body);

        if (responseBody is List) {
          Map<String, int> leaveTypes = {
            for (var item in responseBody)
              item['leavetype']: int.tryParse(item['count']) ?? 0
          };

          setState(() {
            _leaveTypes = leaveTypes;
          });
        } else {
          _setStatusMessage('Unexpected response format: ${response.body}');
        }
      } else {
        _setStatusMessage('Failed to fetch leave types: ${response.body}');
      }
    } catch (e) {
      _setStatusMessage('Failed to fetch leave types: $e');
    }
  }

  Future<void> _fetchEmployees() async {
    final loginState = Provider.of<LoginState>(context, listen: false);
    try {
      final managerResponse = await http.post(
        Uri.parse('https://hrms.vliv.app/employee/managercount'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'companyemail': loginState.companyEmail,
          'companyid': loginState.companyId,
          'value': true,
        }),
      );

      if (managerResponse.statusCode == 200) {
        final managerResponseBody = jsonDecode(managerResponse.body);
        if (managerResponseBody['data'] != null && managerResponseBody['data'] is List) {
          setState(() {
            _managers = managerResponseBody['data']
                .map<String>((item) => item['name'] as String)
                .toList();
          });
        } else {
          _setStatusMessage('Unexpected response format: ${managerResponse.body}');
        }
      } else {
        _setStatusMessage('Failed to fetch manager count: ${managerResponse.body}');
      }
    } catch (e) {
      _setStatusMessage('Failed to fetch employees: $e');
    }
  }

  Future<void> _applyLeave() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    final loginState = Provider.of<LoginState>(context, listen: false);
    _setLoading(true);

    try {
      final response = await http.post(
        Uri.parse('https://hrms.vliv.app/attedance/leave/add'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'empname': loginState.userName,
          'empid': loginState.employeeId,
          'leavetype': _selectedLeaveType,
          'leavebalance': _leaveBalanceController.text,
          'firsthalf': _firstHalf ? '1' : '0',
          'secondhalf': _secondHalf ? '1' : '0',
          'appliedto': _appliedToController.text,
          'attachfile': _attachFile ?? '',
          'fromdate': _fromDateController.text,
          'todate': _toDateController.text,
          'noofdays': _noOfDaysController.text,
          'reason': _reasonController.text,
          'ccto': _selectedCC,
          'companyemail': loginState.companyEmail,
          'companyid': loginState.companyId,
          'date': DateTime.now().toIso8601String(),
        }),
      );

      if (response.statusCode == 200) {
        _setStatusMessage('Leave applied successfully');
      } else {
        _setStatusMessage('Failed to apply leave: ${response.body}');
      }
    } catch (e) {
      _setStatusMessage('Failed to apply leave: $e');
    } finally {
      _setLoading(false);
    }
  }

  void _calculateNoOfDays() {
    if (_fromDateController.text.isEmpty || _toDateController.text.isEmpty) {
      _noOfDaysController.text = '0';
      return;
    }

    final fromDate = DateTime.parse(_fromDateController.text);
    final toDate = DateTime.parse(_toDateController.text);
    double daysDiff = toDate.difference(fromDate).inDays + 1;

    if (_firstHalf && _secondHalf) {
    } else if (_firstHalf || _secondHalf) {
      daysDiff -= 0.5;
    }

    _noOfDaysController.text = daysDiff.toString();
  }

  Future<void> _pickFile() async {
    try {
      _setLoading(true);
      FilePickerResult? result = await FilePicker.platform.pickFiles();

      if (result != null) {
        File file = File(result.files.single.path!);
        var request = http.MultipartRequest(
          'POST',
          Uri.parse('https://hrms.vliv.app/attedance/fileattach'),
        );
        request.files.add(await http.MultipartFile.fromPath('file', file.path));
        var res = await request.send();

        if (res.statusCode == 200) {
          var responseData = await res.stream.bytesToString();
          var jsonResponse = jsonDecode(responseData);
          setState(() {
            _attachFile = jsonResponse['file'];
          });
        } else {
          _setStatusMessage('Failed to upload file: ${res.reasonPhrase}');
        }
      } else {
        _setStatusMessage('No file selected');
      }
    } catch (e) {
      _setStatusMessage('Error picking or uploading file: $e');
    } finally {
      _setLoading(false);
    }
  }

  void _setStatusMessage(String message) {
    setState(() {
      _statusMessage = message;
    });
  }

  void _setLoading(bool isLoading) {
    setState(() {
      _isLoading = isLoading;
    });
  }

  @override
  Widget build(BuildContext context) {
    final loginState = Provider.of<LoginState>(context);

    if (!loginState.isLoggedIn) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.pushReplacementNamed(context, '/login');
      });
      return const SizedBox.shrink();
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Apply Leave'),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              children: [
                TextFormField(
                  initialValue: loginState.userName,
                  decoration: InputDecoration(
                    labelText: 'Employee Name',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                  readOnly: true,
                ),
                const SizedBox(height: 16.0),
                DropdownButtonFormField<String>(
                  value: _selectedLeaveType,
                  items: _leaveTypes.isNotEmpty
                      ? _leaveTypes.keys.map((String leaveType) {
                          return DropdownMenuItem<String>(
                            value: leaveType,
                            child: Text(leaveType),
                          );
                        }).toList()
                      : [DropdownMenuItem<String>(value: null, child: Text('No leave types available'))],
                  onChanged: (newValue) {
                    setState(() {
                      _selectedLeaveType = newValue;
                      _leaveBalanceController.text = _leaveTypes[newValue]?.toString() ?? '0';
                      _appliedToController.text = _managers.isNotEmpty ? _managers.first : '';
                    });
                  },
                  decoration: InputDecoration(
                    labelText: 'Leave Type',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                  validator: (value) => value == null ? 'Please select a leave type' : null,
                ),
                const SizedBox(height: 16.0),
                TextFormField(
                  controller: _leaveBalanceController,
                  decoration: InputDecoration(
                    labelText: 'Leave Balance',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                  readOnly: true,
                ),
                const SizedBox(height: 16.0),
                TextFormField(
                  controller: _fromDateController,
                  decoration: InputDecoration(
                    labelText: 'From Date',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    suffixIcon: Icon(Icons.calendar_today),
                  ),
                  validator: (value) => value!.isEmpty ? 'Please enter from date' : null,
                  onTap: () async {
                    DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2101),
                    );
                    if (pickedDate != null) {
                      setState(() {
                        _fromDateController.text = "${pickedDate.toLocal()}".split(' ')[0];
                        _calculateNoOfDays();
                      });
                    }
                  },
                ),
                const SizedBox(height: 16.0),
                TextFormField(
                  controller: _toDateController,
                  decoration: InputDecoration(
                    labelText: 'To Date',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    suffixIcon: Icon(Icons.calendar_today),
                  ),
                  validator: (value) => value!.isEmpty ? 'Please enter to date' : null,
                  onTap: () async {
                    DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2101),
                    );
                    if (pickedDate != null) {
                      setState(() {
                        _toDateController.text = "${pickedDate.toLocal()}".split(' ')[0];
                        _calculateNoOfDays();
                      });
                    }
                  },
                ),
                const SizedBox(height: 16.0),
                Row(
                  children: [
                    Expanded(
                      child: SwitchListTile(
                        title: const Text('First Half'),
                        value: _firstHalf,
                        onChanged: (bool value) {
                          setState(() {
                            _firstHalf = value;
                            _calculateNoOfDays();
                          });
                        },
                      ),
                    ),
                    Expanded(
                      child: SwitchListTile(
                        title: const Text('Second Half'),
                        value: _secondHalf,
                        onChanged: (bool value) {
                          setState(() {
                            _secondHalf = value;
                            _calculateNoOfDays();
                          });
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16.0),
                TextFormField(
                  controller: _noOfDaysController,
                  decoration: InputDecoration(
                    labelText: 'No of Days',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                  readOnly: true,
                ),
                const SizedBox(height: 16.0),
                ElevatedButton(
                  onPressed: _pickFile,
                  child: const Text('Choose File'),
                ),
                const SizedBox(height: 16.0),
                TextFormField(
                  controller: _appliedToController,
                  decoration: InputDecoration(
                    labelText: 'Applied To',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                  readOnly: true,
                ),
                const SizedBox(height: 16.0),
                TextFormField(
                  controller: _reasonController,
                  decoration: InputDecoration(
                    labelText: 'Reason',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                  validator: (value) => value!.isEmpty ? 'Please enter reason' : null,
                ),
                const SizedBox(height: 16.0),
                DropdownButtonFormField<String>(
                  value: _selectedCC,
                  items: _ccEmployees.map((String employee) {
                    return DropdownMenuItem<String>(
                      value: employee,
                      child: Text(employee),
                    );
                  }).toList(),
                  onChanged: (newValue) {
                    setState(() {
                      _selectedCC = newValue;
                    });
                  },
                  decoration: InputDecoration(
                    labelText: 'CC To',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                  // validator: (value) => value == null ? 'Please select a CC employee' : null,
                ),
                const SizedBox(height: 16.0),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: const Text('Cancel'),
                    ),
                    ElevatedButton(
                      onPressed: _applyLeave,
                      child: const Text('Submit'),
                    ),
                  ],
                ),
                const SizedBox(height: 16.0),
                Text(_statusMessage),
              ],
            ),
          ),
        ),
      ),
    );
  }
}