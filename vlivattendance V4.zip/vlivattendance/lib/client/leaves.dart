import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../state/login_state.dart';

class Leaves extends StatefulWidget {
  const Leaves({super.key});

  @override
  _LeavesState createState() => _LeavesState();
}

class _LeavesState extends State<Leaves> {
  bool _isLoading = false;
  List<Map<String, dynamic>> _appliedLeaves = [];
  Map<String, dynamic> _remainingLeaves = {};

  @override
  void initState() {
    super.initState();
    _fetchAppliedLeaves();
    _fetchRemainingLeaves();
  }

  Future<void> _fetchAppliedLeaves() async {
    final loginState = Provider.of<LoginState>(context, listen: false);
    setState(() {
      _isLoading = true;
    });

    final url = Uri.parse('https://hrms.vliv.app/attedance/leave/getbyemployee');
    final headers = {'Content-Type': 'application/json'};
    final body = jsonEncode({
      'employeeid': loginState.employeeId,
      'companyid': loginState.companyId,
      'companyemail': loginState.companyEmail,
    });

    try {
      final response = await http.post(url, headers: headers, body: body);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _appliedLeaves = List<Map<String, dynamic>>.from(data);
        });
      } else {
        setState(() {
          _appliedLeaves = [];
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to get applied leaves. Status code: ${response.statusCode}')),
        );
      }
    } catch (e) {
      setState(() {
        _appliedLeaves = [];
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error occurred: $e')),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _fetchRemainingLeaves() async {
    final loginState = Provider.of<LoginState>(context, listen: false);
    setState(() {
      _isLoading = true;
    });

    final url = Uri.parse('https://hrms.vliv.app/attedance/leave/remainingleaves');
    final headers = {'Content-Type': 'application/json'};
    final body = jsonEncode({
      'employeeid': loginState.employeeId,
      'companyid': loginState.companyId,
      'companyemail': loginState.companyEmail,
    });

    try {
      final response = await http.post(url, headers: headers, body: body);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _remainingLeaves = data;
        });
      } else {
        setState(() {
          _remainingLeaves = {};
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to get remaining leaves. Status code: ${response.statusCode}')),
        );
      }
    } catch (e) {
      setState(() {
        _remainingLeaves = {};
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error occurred: $e')),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final loginState = Provider.of<LoginState>(context);

    if (!loginState.isLoggedIn) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.pushReplacementNamed(context, '/login');
      });
      return const SizedBox.shrink();
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Leaves'),
        backgroundColor: Colors.deepPurple,
      ),
      body: Center(
        child: _isLoading
            ? const CircularProgressIndicator()
            : Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const Text(
                      'Applied Leaves:',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 10),
                    Expanded(
                      child: ListView.builder(
                        itemCount: _appliedLeaves.length,
                        itemBuilder: (context, index) {
                          final leave = _appliedLeaves[index];
                          return Card(
                            elevation: 4,
                            margin: const EdgeInsets.symmetric(vertical: 8),
                            child: ListTile(
                              title: Text('Leave Type: ${leave['leavetype']}'),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('From Date: ${leave['fromdate']}'),
                                  Text('To Date: ${leave['todate']}'),
                                  Text('Reason: ${leave['reason']}'),
                                  Text('Status: ${leave['status']}'),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'Remaining Leaves:',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 10),
                    Card(
                      elevation: 4,
                      margin: const EdgeInsets.symmetric(vertical: 8),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Total: ${_remainingLeaves['total'] ?? 0}',
                              style: const TextStyle(fontSize: 16),
                            ),
                            Text(
                              'Used: ${_remainingLeaves['used'] ?? 0}',
                              style: const TextStyle(fontSize: 16),
                            ),
                            Text(
                              'Balance: ${_remainingLeaves['balance'] ?? 0}',
                              style: const TextStyle(fontSize: 16),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
      ),
    );
  }
}
