import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/login_state.dart';
import 'attendance.dart';
import 'my_logs.dart';
import 'leave.dart';
import 'profile.dart';
import 'leaves.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    final loginState = Provider.of<LoginState>(context);

    if (!loginState.isLoggedIn) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.pushReplacementNamed(
          context,
          '/login',
        );
      });
      return const SizedBox.shrink();
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
        backgroundColor: Colors.deepPurple,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.deepPurple,
              ),
              child: Text(
                'Menu',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text('Home'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushReplacementNamed(context, '/home');
              },
            ),
            ListTile(
              leading: Icon(Icons.check_circle),
              title: Text('Attendance'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/attendance');
              },
            ),
            ListTile(
              leading: Icon(Icons.list),
              title: Text('Logs'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/my_logs');
              },
            ),
            ListTile(
              leading: Icon(Icons.beach_access),
              title: Text('Leave Management'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/leave');
              },
            ),
            ListTile(
              leading: Icon(Icons.person),
              title: Text('Profile'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/profile');
              },
            ),
            ListTile(
              leading: Icon(Icons.logout),
              title: Text('Logout'),
              onTap: () async {
                bool confirm = await showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Text('Confirm Logout'),
                    content: Text('Are you sure you want to logout?'),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.of(context).pop(false),
                        child: Text('Cancel'),
                      ),
                      TextButton(
                        onPressed: () {
                          loginState.logout();
                          Navigator.of(context).pop(true);
                          Navigator.pushReplacementNamed(context, '/login');
                        },
                        child: Text('Logout'),
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          Center(
            child: Text(
              'Welcome',
              style: TextStyle(
                fontSize: 24, 
                fontWeight: FontWeight.bold,
                color: Colors.deepPurple,
              ),
            ),
          ),
          const SizedBox(height: 20),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            mainAxisSpacing: 20,
            crossAxisSpacing: 20,
            children: [
              _buildHomeOption(
                icon: Icons.check_circle,
                label: 'Attendance',
                onTap: () {
                  Navigator.pushNamed(context, '/attendance');
                },
              ),
              _buildHomeOption(
                icon: Icons.list,
                label: 'Logs',
                onTap: () {
                  Navigator.pushNamed(context, '/my_logs');
                },
              ),
              _buildHomeOption(
                icon: Icons.beach_access,
                label: 'Leave',
                onTap: () {
                  Navigator.pushNamed(context, '/leave');
                },
              ),
              _buildHomeOption(
                icon: Icons.person,
                label: 'Profile',
                onTap: () {
                  Navigator.pushNamed(context, '/profile');
                },
              ),
              _buildHomeOption(
                icon: Icons.calendar_today,
                label: 'Leaves', 
                onTap: () {
                  Navigator.pushNamed(context, '/leaves');

                  
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHomeOption({required IconData icon, required String label, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.deepPurple.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12.0),
        ),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 50, color: Colors.deepPurple),
            const SizedBox(height: 8.0),
            Text(label, style: TextStyle(color: Colors.deepPurple)),
          ],
        ),
      ),
    );
  }
}