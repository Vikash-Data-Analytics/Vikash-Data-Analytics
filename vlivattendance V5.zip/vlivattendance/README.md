Author: @ Viaksh Kumar Chaudhary
# vlivattendance
A In-house developed product of venturesathi business services llp.
This android application has features listed below:-
1. Centralized Login.
2. Home Page For Other Navigations Tools.
3. Geo Fencing based map embeded Attendance.
4. Attendance Marking.
5. Attendance Logs.
6. Leave Request & Approval.
7. Leave Logs.
8. Log Out.