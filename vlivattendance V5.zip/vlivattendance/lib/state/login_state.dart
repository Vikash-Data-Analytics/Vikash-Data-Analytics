import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginState extends ChangeNotifier {
  final String _baseUrl = 'https://vliv.app/user/loginuser';
  String _errorMessage = '';
  bool _isLoggedIn = false;
  String _token = '';
  String _employeeId = '';
  String _companyId = '';
  String _userName = '';
  String _userEmail = '';
  String _companyEmail = '';
  String _empId = ''; 
  String _reportingManager = ''; 

  String get errorMessage => _errorMessage;
  bool get isLoggedIn => _isLoggedIn;
  String get token => _token;
  String get employeeId => _employeeId;
  String get companyId => _companyId;
  String get userName => _userName;
  String get userEmail => _userEmail;
  String get companyEmail => _companyEmail;
  String get empId => _empId; 
  String get reportingManager => _reportingManager; 

  Future<bool> login(String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse(_baseUrl),
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS, HEAD',
          'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        },
        body: jsonEncode({
          'email': email,
          'password': password,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _token = data['token'] ?? '';
        _employeeId = data['data']['empid'] ?? '';
        _companyId = data['data']['companyid']?.toString() ?? '';
        _userName = data['data']['username'] ?? '';
        _userEmail = data['data']['email'] ?? '';
        _companyEmail = data['data']['companyemail'] ?? '';
        _empId = data['data']['empid'] ?? '';
        _reportingManager = data['data']['reportmanager'] ?? '';
        _isLoggedIn = true;
        await saveAuthToken();
        notifyListeners();
        return true;
      } else {
        _errorMessage = 'Failed to login: ${response.reasonPhrase} (Status Code: ${response.statusCode})';
        notifyListeners();
        return false;
      }
    } catch (e) {
      _errorMessage = 'Failed to login: $e';
      notifyListeners();
      return false;
    }
  }

  Future<void> saveAuthToken() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', _token);
    await prefs.setString('employee_id', _employeeId);
    await prefs.setString('company_id', _companyId);
    await prefs.setString('user_name', _userName);
    await prefs.setString('user_email', _userEmail);
    await prefs.setString('company_email', _companyEmail);
  }

  Future<bool> checkAuthToken() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('auth_token');
    if (token != null && token.isNotEmpty) {
      _token = token;
      _employeeId = prefs.getString('employee_id') ?? '';
      _companyId = prefs.getString('company_id') ?? '';
      _userName = prefs.getString('user_name') ?? '';
      _userEmail = prefs.getString('user_email') ?? '';
      _companyEmail = prefs.getString('company_email') ?? '';
      _isLoggedIn = true;
      notifyListeners();
      return true;
    }
    return false;
  }

  Future<void> clearAuthToken() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
    await prefs.remove('employee_id');
    await prefs.remove('company_id');
    await prefs.remove('user_name');
    await prefs.remove('user_email');
    await prefs.remove('company_email');
  }

  Future<void> logout() async {
    await clearAuthToken();
    _isLoggedIn = false;
    _token = '';
    _employeeId = '';
    _companyId = '';
    _userName = '';
    _userEmail = '';
    _companyEmail = '';
    _empId = ''; 
    _reportingManager = ''; 
    notifyListeners();
  }
}