import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/login_state.dart';
import 'attendance.dart';
import 'my_logs.dart';
import 'leave.dart';
import 'profile.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;

  static final List<Widget> _widgetOptions = <Widget>[
    AttendancePage(),
    MyLogsPage(),
    LeavePage(),
    ProfilePage(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  Future<void> _confirmLogout(BuildContext context) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Confirm Logout'),
          content: SingleChildScrollView(
            child: ListBody(
              children: const <Widget>[
                Text('Are you sure you want to logout?'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: const Text('Logout'),
              onPressed: () {
                Navigator.of(context).pop();
                final loginState = Provider.of<LoginState>(context, listen: false);
                loginState.logout();
                Navigator.pushReplacementNamed(context, '/login');
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final loginState = Provider.of<LoginState>(context);

    if (!loginState.isLoggedIn) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.pushReplacementNamed(context, '/login');
      });
      return const SizedBox.shrink();
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
        backgroundColor: Color(0xFF37668F),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: () {
              setState(() {
                _widgetOptions[0] = AttendancePage();
              });
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              decoration: BoxDecoration(
                color: Color(0xFF1C4167),
              ),
              accountName: Text(
                loginState.userName,
                style: TextStyle(
                  color: Color(0xFFF4FAFF),
                  fontSize: 18,
                ),
              ),
              accountEmail: Text(
                loginState.companyEmail,
                style: TextStyle(
                  color: Color(0xFFF4FAFF),
                  fontSize: 14,
                ),
              ),
              currentAccountPicture: CircleAvatar(
                backgroundColor: Color(0xFFF4FAFF),
                child: Text(
                  loginState.userName[0],
                  style: TextStyle(
                    fontSize: 40.0,
                    color: Color(0xFF1C4167),
                  ),
                ),
              ),
            ),
           
            ListTile(
              leading: Icon(Icons.event, color: Color(0xFF1C4167)),
              title: Text('National Holidays', style: TextStyle(color: Color(0xFF1C4167))),
              onTap: () {
                
              },
            ),
            ListTile(
              leading: Icon(Icons.festival, color: Color(0xFF1C4167)),
              title: Text('Festivals', style: TextStyle(color: Color(0xFF1C4167))),
              onTap: () {
                
              },
            ),
             ListTile(
              leading: Icon(Icons.exit_to_app, color: Color(0xFF1C4167)),
              title: Text('Logout', style: TextStyle(color: Color(0xFF1C4167))),
              onTap: () {
                _confirmLogout(context);
              },
            ),
          ],
        ),
      ),
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 300),
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.location_on),
            label: 'Attendance',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.list),
            label: 'Logs',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today),
            label: 'Leaves',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Color(0xFF37668F),
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
        type: BottomNavigationBarType.fixed,
      ),
    );
  }
}