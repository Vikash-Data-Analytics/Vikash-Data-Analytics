import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:table_calendar/table_calendar.dart';
import '../state/login_state.dart';
import 'package:intl/intl.dart';

class MyLogsPage extends StatefulWidget {
  const MyLogsPage({super.key});

  @override
  _MyLogsPageState createState() => _MyLogsPageState();
}

class _MyLogsPageState extends State<MyLogsPage> {
  bool _isLoading = false;
  String _statusMessage = '';
  List<dynamic> _logs = [];
  Map<DateTime, List<dynamic>> _events = {};
  DateTime _selectedDay = DateTime.now();
  DateTime _focusedDay = DateTime.now();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final loginState = Provider.of<LoginState>(context, listen: false);
      _fetchLogs(loginState.token, loginState.employeeId, loginState.companyEmail, loginState.companyId);
    });
  }

  Future<void> _fetchLogs(String token, String employeeId, String companyEmail, String companyId) async {
    setState(() {
      _isLoading = true;
      _statusMessage = '';
    });

    try {
      final response = await http.post(
        Uri.parse('https://hrms.vliv.app/atte/getbyemployee'),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'employeeid': employeeId,
          'companyemail': companyEmail,
          'companyid': companyId,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body)['data'];
        setState(() {
          _logs = data;
          _events = _groupLogsByDate(data);
          _isLoading = false;
        });
      } else {
        setState(() {
          _statusMessage = 'Failed to load logs';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _statusMessage = 'An error occurred';
        _isLoading = false;
      });
    }
  }

  Map<DateTime, List<dynamic>> _groupLogsByDate(List<dynamic> logs) {
    Map<DateTime, List<dynamic>> events = {};
    for (var log in logs) {
      DateTime logDate = DateFormat('dd/MM/yyyy').parse(log['date']);
      if (events[logDate] == null) {
        events[logDate] = [];
      }
      events[logDate]!.add(log);
    }
    return events;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Logs'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                TableCalendar(
                  firstDay: DateTime.utc(2020, 1, 1),
                  lastDay: DateTime.utc(2030, 12, 31),
                  focusedDay: _focusedDay,
                  selectedDayPredicate: (day) {
                    return isSameDay(_selectedDay, day);
                  },
                  onDaySelected: (selectedDay, focusedDay) {
                    setState(() {
                      _selectedDay = selectedDay;
                      _focusedDay = focusedDay;
                    });
                  },
                  eventLoader: (day) {
                    return _events[day] ?? [];
                  },
                ),
                const SizedBox(height: 8.0),
                if (_events[_selectedDay] != null && _events[_selectedDay]!.isNotEmpty)
                  Column(
                    children: _events[_selectedDay]!.map<Widget>((log) {
                      return ListTile(
                        title: Text('Check-in: ${log['checkin']}'),
                        subtitle: Text('Check-out: ${log['checkout']}'),
                      );
                    }).toList(),
                  ),
                const SizedBox(height: 8.0),
                Expanded(
                  child: ListView.builder(
                    itemCount: _events[_selectedDay]?.length ?? 0,
                    itemBuilder: (context, index) {
                      var log = _events[_selectedDay]![index];
                      return ListTile(
                        title: Text('Check-in: ${log['checkin']}'),
                        subtitle: Text('Check-out: ${log['checkout']}'),
                        onTap: () {
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                title: Text('Log Details'),
                                content: SingleChildScrollView(
                                  child: ListBody(
                                    children: <Widget>[
                                      Text('Check-in: ${log['checkin']}'),
                                      Text('Check-out: ${log['checkout']}'),
                                      Text('Date: ${log['date']}'),
                                      Text('Employee ID: ${log['employeeid']}'),
                                      Text('Company ID: ${log['companyid']}'),
                                    ],
                                  ),
                                ),
                                actions: <Widget>[
                                  TextButton(
                                    child: Text('Close'),
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                  ),
                                ],
                              );
                            },
                          );
                        },
                      );
                    },
                  ),
                ),
                if (_statusMessage.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      _statusMessage,
                      style: const TextStyle(color: Colors.red),
                    ),
                  ),
              ],
            ),
    );
  }
}
