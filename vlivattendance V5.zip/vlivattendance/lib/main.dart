import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'state/login_state.dart';
import 'client/home.dart';
import 'client/login.dart';
import 'client/attendance.dart';
import 'client/my_logs.dart';
import 'client/leave.dart';
import 'client/profile.dart';
import 'client/leaves.dart'; 
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:flutter/foundation.dart' show defaultTargetPlatform, kIsWeb;
import 'package:google_maps_flutter_platform_interface/google_maps_flutter_platform_interface.dart';
import 'package:google_maps_flutter_android/google_maps_flutter_android.dart';
import 'dart:io' show Platform;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final loginState = LoginState();
  final isLoggedIn = await loginState.checkAuthToken();

  if (kIsWeb || Platform.isAndroid || Platform.isIOS) {
    final GoogleMapsFlutterPlatform mapsImplementation =
        GoogleMapsFlutterPlatform.instance;
    if (mapsImplementation is GoogleMapsFlutterAndroid) {
      mapsImplementation.useAndroidViewSurface = true;
    }
  }

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: loginState),
      ],
      child: MyApp(isLoggedIn: isLoggedIn),
    ),
  );
}

class MyApp extends StatelessWidget {
  final bool isLoggedIn;
  const MyApp({super.key, required this.isLoggedIn});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vliv Attendance',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        textTheme: const TextTheme(
          headlineLarge: TextStyle(fontSize: 32.0, fontWeight: FontWeight.bold, color: Color.fromARGB(255, 10, 104, 192), fontFamily: 'Roboto'),
        ),
      ),
      initialRoute: isLoggedIn ? '/home' : '/login',
      routes: {
        '/login': (context) => const LoginPage(),
        '/home': (context) => const HomePage(),
        '/attendance': (context) => const AttendancePage(),
        '/my_logs': (context) => const MyLogsPage(),
        '/leave': (context) => const LeavePage(),
        '/profile': (context) => const ProfilePage(),
        '/leaves': (context) => const Leaves(), 
      },
    );
  }
}